import { Component,ViewEncapsulation } from '@angular/core';
import {MyserviceService} from './myservice.service';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  title = 'advids-portfolio';
  flag1:boolean=false;
  selectedValue:any=1;
  selectedValue1:any=1;
  financialData:any=[
    {id:1, name:"Videos by Industry" },
    { id:2 , name:"Consulting & Services"},
    { id:3 , name:"Education & Nonprofit"},
    { id:4 , name:"Hardware & Manufacturing"},
    { id:5 , name:"Healthcare & Life Sciences"},
    { id:6 , name:"IT, Internet ,Software"},
    { id:7 , name:"Logistics & Distribution"},
    { id:8 , name:"Mobile & Apps"},
    { id:9 , name:"Retail & Ecommerce"},
    { id:10 , name:"Technology"}
    
    ];
     
  salesData:any=[
    {id:1 , name:"Sales & Marketing"},
    { id:2 , name:"Product Demo"},
    { id:3 , name:"Company & Brand Overview"},
    { id:4 , name:"Website Landing Page"},
    { id:5 , name:"Process & How To"},
    { id:6 , name:"Walkthrough & Installation"},
    { id:7 , name:"Explanation"},
    { id:8 , name:"Case Study"}
    ];
  styles:any=[
    { id:1 , name:"Videos By style"},
    {id:2 , name:"2D Motion Graphics"},
    { id:3 , name:"3D Motion Graphics"}
    ];


  constructor(public Myservice:MyserviceService){
 
    //this.financialData= this.Myservice.getFinancialData();
//this.salesData= this.Myservice.getSalesData();


  }


}
